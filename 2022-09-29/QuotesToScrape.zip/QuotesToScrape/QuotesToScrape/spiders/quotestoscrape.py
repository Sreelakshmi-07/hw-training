import scrapy
from scrapy.http import Request
import json
from ..items import QuotestoscrapeItem


class Quotes(scrapy.Spider):

    name = 'qts'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36'
    }
    url = 'http://quotes.toscrape.com/api/quotes?page=1'

    def start_requests(self):

        yield Request(
            url=self.url, headers=self.headers, callback=self.parse
        )

    def parse(self, response):

        item = QuotestoscrapeItem()
        res = json.loads(response.body)
        # print(res)
        quotes = res.get('quotes')
        for details in quotes:
            author = details['author']['name'].strip()
            link = details['author']['goodreads_link'].strip()
            tags = details['tags']
            description = details['text'].strip()
            item['author'] = author
            item['link'] = link
            item['tags'] = tags
            item['description'] = description
            yield item

        has_next = res['has_next']
        if has_next:
            next_page = res['page'] + 1
            yield Request(
                url=f"http://quotes.toscrape.com/api/quotes?page={next_page}",
                headers=self.headers, callback=self.parse
            )
