import scrapy
from scrapy.http import Request
from ..items import HouzaItem
import json


class Houza(scrapy.Spider):

    name = 'houza'
    headers = {
        'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'sec-gpc': '1',
        # 'sentry-trace': '3a57f52aaf704f3181b61438edb8d3bc-b47022bcad2329ff-0',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36'
    }
    urls = ['https://api.houza.com/api/v1/properties?listingType=SALE&page=',
            'https://api.houza.com/api/v1/properties?listingType=RENT&page=']

    def start_requests(self):

        for urls in self.urls:
            req_url = urls
            for page in range(1, 497):
                url = req_url + str(page)
                yield Request(
                    url=url, headers=self.headers, callback=self.parse
                )

    def parse(self, response):

        if response.status == 200:
            allowed_domain = 'https://houza.com'
            item = HouzaItem()
            res = json.loads(response.body)
            data = res.get('properties')
            for r in data:
                listing_type = r['listingType']
                url = allowed_domain + r['url']
                item['listing_type'] = listing_type
                item['url'] = url
                yield item
